// Default team names and scores
let teamA = { name: 'Team A', score: 0 };
let teamB = { name: 'Team B', score: 0 };

// Function to simulate score update
function updateScores() {
    // Simulating scores using random values
    teamA.score = Math.floor(Math.random() * 5);  // Random score between 0 and 4
    teamB.score = Math.floor(Math.random() * 5);  // Random score between 0 and 4

    // Update team names and scores in the DOM
    document.getElementById('teamAName').innerText = teamA.name;
    document.getElementById('teamAScore').innerText = teamA.score;

    document.getElementById('teamBName').innerText = teamB.name;
    document.getElementById('teamBScore').innerText = teamB.score;

    // Determine result and update the result div
    let resultText = '';
    if (teamA.score > teamB.score) {
        resultText = `${teamA.name} Wins!`;
    } else if (teamA.score < teamB.score) {
        resultText = `${teamB.name} Wins!`;
    } else {
        resultText = 'It\'s a Draw!';
    }

    document.getElementById('matchResult').innerText = resultText;
}
