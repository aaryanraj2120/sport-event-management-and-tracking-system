from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.forms import AuthenticationForm
from .models import Recipe, Player, Sport
from .forms import RecipeForm
from django.http import JsonResponse

def home(request):
    if request.user.is_authenticated:
        recipes = Recipe.objects.all()
        login_form = None
    else:
        recipes = []
        login_form = AuthenticationForm()
    return render(request, 'recipes/home.html', {'recipes': recipes, 'login_form': login_form})

def add_recipe(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = RecipeForm()
    return render(request, 'recipes/add_recipe.html', {'form': form})

def edit_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        form = RecipeForm(request.POST, instance=recipe)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = RecipeForm(instance=recipe)
    return render(request, 'recipes/edit_recipe.html', {'form': form})

def delete_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        recipe.delete()
        return redirect('home')
    return render(request, 'recipes/delete_recipe.html', {'recipe': recipe})

def recipe_detail(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        team1_score = request.POST.get('team1_score')
        team2_score = request.POST.get('team2_score')
        recipe.team1_score = int(team1_score)
        recipe.team2_score = int(team2_score)
        recipe.save()

        # Determine the winner
        if recipe.team1_score > recipe.team2_score:
            winner = recipe.team1_name
        elif recipe.team2_score > recipe.team1_score:
            winner = recipe.team2_name
        else:
            winner = "Draw"

        return render(request, 'recipes/recipe_detail.html', {'recipe': recipe, 'winner': winner})
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

def update_score(request):
    if request.method == 'POST':
        event_id = request.POST.get('event')
        home_score = request.POST.get('homeScore')
        away_score = request.POST.get('awayScore')

        if not event_id or not home_score or not away_score:
            # Handle missing data
            return redirect('home')

        recipe = get_object_or_404(Recipe, id=event_id)
        recipe.team1_score = int(home_score)
        recipe.team2_score = int(away_score)
        recipe.save()

        # Determine the winner
        if recipe.team1_score > recipe.team2_score:
            winner = recipe.team1_name
        elif recipe.team2_score > recipe.team1_score:
            winner = recipe.team2_name
        else:
            winner = "Draw"

        # Redirect to the recipe_detail page with the winner information
        return redirect('recipe_detail', id=recipe.id)

    return redirect('home')

def chess_detail(request, id):
    recipe = get_object_or_404(Recipe, id=id)  # Get the specific recipe instance
    
    # Initialize scores if they don't exist
    if recipe.team1_score is None:
        recipe.team1_score = 0
    if recipe.team2_score is None:
        recipe.team2_score = 0

    # Handle score update if POST request
    if request.method == 'POST':
        home_score = request.POST.get('homeScore', 0)
        away_score = request.POST.get('awayScore', 0)
        recipe.team1_score = int(home_score)
        recipe.team2_score = int(away_score)
        recipe.save()
        return redirect('chess_detail', id=id)  # Redirect to the same page

    return render(request, 'recipes/chess_detail.html', {'recipe': recipe})  # Pass the recipe instance

def players_view(request):
    players = Player.objects.all()
    sports = Sport.objects.all()
    return render(request, 'recipes/players01.html', {
        'players': players,
        'sports': sports
    })

def add_player(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        sport_id = request.POST.get('sport')
        matches_played = request.POST.get('matches_played', 0)
        wins = request.POST.get('wins', 0)
        losses = request.POST.get('losses', 0)

        sport = get_object_or_404(Sport, id=sport_id)
        Player.objects.create(
            name=name,
            sport=sport,
            matches_played=matches_played,
            wins=wins,
            losses=losses
        )
        return redirect('players_view')
    return redirect('players_view')