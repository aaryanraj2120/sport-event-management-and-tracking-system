from django.db import models
from django.conf import settings

# Create your models here.

class DietaryPreference(models.Model):
    name = models.CharField(max_length=100)

class Recipe(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.TextField()
    team1_name = models.CharField(max_length=100, default='Team 1')  # New Field
    team2_name = models.CharField(max_length=100, default='Team 2')  # New Field
    team1_score = models.IntegerField(default=0)                     # New Field
    team2_score = models.IntegerField(default=0)                     # New Field
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class RecipeIngredient(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    ingredient = models.ForeignKey('ingredients.Ingredient', on_delete=models.CASCADE)
    quantity = models.CharField(max_length=50)

class Favorite(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)

class CookingHistory(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    date_cooked = models.DateTimeField(auto_now_add=True)

class Sport(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Player(models.Model):
    name = models.CharField(max_length=200)
    matches_played = models.IntegerField(default=0)
    wins = models.IntegerField(default=0)
    losses = models.IntegerField(default=0)
    sport = models.ForeignKey(Sport, on_delete=models.CASCADE, related_name='players')

    def performance_percentage(self):
        if self.matches_played > 0:
            return (self.wins / self.matches_played) * 100
        return 0