from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from .views import recipe_detail, update_score

urlpatterns = [
    path('', views.home, name='home'),
    path('add/', views.add_recipe, name='add_recipe'),
    path('edit/<int:id>/', views.edit_recipe, name='edit_recipe'),
    path('delete/<int:id>/', views.delete_recipe, name='delete_recipe'),
    path('recipe/<int:id>/', recipe_detail, name='recipe_detail'),
    path('login/', auth_views.LoginView.as_view(template_name='recipes/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('update-score/', update_score, name='update_score'),
    path('players/', views.players_view, name='players_view'),
    path('players/add/', views.add_player, name='add_player'),
]