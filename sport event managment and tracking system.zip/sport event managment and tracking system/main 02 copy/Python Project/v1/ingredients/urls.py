from django.urls import path
from . import views

app_name = 'ingredients'  # Namespace for the app

urlpatterns = [
    path('', views.ingredient_list, name='ingredient_list'),
    path('<int:id>/', views.ingredient_detail, name='ingredient_detail'),
    # Add more URL patterns as needed
]
